package com.example.musicremover

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color

class MainActivity : Activity() {
    private val instruments = listOf(
        "Vocals / आवाज़", "Drums / ढोल", "Bass guitar", "Guitar", "Piano / Keyboard",
        "Tabla", "Dholak", "Flute / बाँसुरी", "Sitar", "Sarangi", "Violin",
        "Harmonium", "Tanpura", "Synthesizer", "Saxophone", "Trumpet",
        "Cello", "Mridangam", "Pakhawaj", "Other music / अन्य संगीत"
    )
    private val selected = mutableMapOf<String, Boolean>()
    private var pickedUri: Uri? = null
    private lateinit var fileLabel: TextView
    private lateinit var statusLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instruments.forEach { selected[it] = true }
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(Color.rgb(248, 249, 252))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Music Remover"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(35, 45, 70))
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "Offline audio studio • Prototype"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 4, 0, 18)
        })

        val pick = Button(this).apply {
            text = "गाना चुनें (MP3 / audio)"
            setOnClickListener { chooseAudio() }
        }
        content.addView(pick)
        fileLabel = TextView(this).apply {
            text = "अभी कोई ऑडियो नहीं चुना गया"
            textSize = 14f
            setPadding(0, 10, 0, 14)
        }
        content.addView(fileLabel)

        content.addView(TextView(this).apply {
            text = "किसे रखना है / किसे हटाना है?"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(35, 45, 70))
            setPadding(0, 12, 0, 8)
        })
        content.addView(TextView(this).apply {
            text = "टिक = रखना • टिक हटाएँ = हटाने के लिए चुनना"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 10)
        })

        instruments.forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 5, 8, 5)
                setBackgroundColor(Color.WHITE)
            }
            val check = CheckBox(this).apply {
                text = name
                textSize = 15f
                isChecked = true
                setOnCheckedChangeListener { _, isChecked -> selected[name] = isChecked }
            }
            row.addView(check, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            content.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.rgb(230, 232, 238)) }
            content.addView(divider, LinearLayout.LayoutParams(-1, 1))
        }

        val process = Button(this).apply {
            text = "चयनित इंस्ट्रूमेंट्स हटाएँ"
            setOnClickListener {
                val keep = selected.filterValues { it }.keys
                val remove = selected.filterValues { !it }.keys
                statusLabel.text = if (pickedUri == null) {
                    "पहले ऑडियो फ़ाइल चुनें।"
                } else {
                    "चयन सेव हुआ।\nरखने के लिए: ${keep.joinToString()}\nहटाने के लिए: ${remove.joinToString()}\n\nध्यान दें: इस prototype में AI source-separation engine अभी जोड़ा नहीं गया है, इसलिए ऑडियो में बदलाव नहीं हुआ।"
                }
            }
        }
        content.addView(process)
        statusLabel = TextView(this).apply {
            text = "स्थिति: ऑडियो चुनकर इंस्ट्रूमेंट्स की पसंद सेट करें।"
            textSize = 14f
            setTextColor(Color.rgb(35, 45, 70))
            setPadding(0, 12, 0, 24)
        }
        content.addView(statusLabel)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Deprecated in Android but supported for this small prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            pickedUri = data?.data
            fileLabel.text = pickedUri?.lastPathSegment ?: "ऑडियो चुना गया"
            statusLabel.text = "ऑडियो चुना गया। इंस्ट्रूमेंट चुनना जारी रखें।"
        }
    }
}
