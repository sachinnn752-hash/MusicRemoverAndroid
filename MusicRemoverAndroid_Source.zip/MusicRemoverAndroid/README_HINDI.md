# Music Remover — Android शुरुआती प्रोजेक्ट

यह अभी शुरुआती Android ऐप/UI prototype है, पूर्ण AI ऑडियो-रिमूवल ऐप नहीं।

## अभी क्या काम करता है?
- फोन से audio file चुनने का विकल्प
- Vocals, Drums, Bass, Guitar, Piano और अन्य वाद्यों की सूची
- हर आइटम के लिए Keep/Remove चुनाव

## अभी क्या बाकी है?
- AI source-separation मॉडल और Android inference integration
- वास्तविक ऑडियो से stems अलग करना और चुने हुए stems को मिलाकर आउटपुट बनाना
- MP3/WAV आउटपुट export तथा अलग-अलग फोन पर परीक्षण

इसलिए अभी ऐप का Remove बटन असली ऑडियो से instruments नहीं हटाता। UI में Guitar, Piano, Tabla आदि दिखने का मतलब यह नहीं कि मॉडल उन्हें अलग-अलग पहचान सकता है। आम source-separation मॉडल अक्सर Vocals/Drums/Bass/Other जैसे stems देता है; प्रत्येक वाद्य को अलग निकालने के लिए उपयुक्त मॉडल आवश्यक है।

## सिर्फ Android मोबाइल से debug APK बनाने का रास्ता
इस प्रोजेक्ट में GitHub Actions workflow जोड़ा गया है, जिससे GitHub पर source डालने के बाद क्लाउड में prototype APK build किया जा सकता है।

1. ZIP को फोन में डाउनलोड करके extract करें।
2. GitHub पर नया repository बनाएँ।
3. Extract किए गए प्रोजेक्ट की सभी फाइलें repository में upload करें; `.github/workflows/build-apk.yml` भी शामिल होना चाहिए।
4. Repository में **Actions** टैब खोलें। अगर पूछा जाए तो workflows enable करें।
5. **Build Music Remover APK** workflow चुनें और **Run workflow** दबाएँ।
6. पूरा होने पर workflow run के नीचे **Artifacts** में `MusicRemover-debug-apk` डाउनलोड करें और ZIP खोलकर APK लें।
7. APK install करने के लिए Android अनुमति माँग सकता है कि उस स्रोत से ऐप install करने दें। केवल अपनी बनाई/विश्वसनीय APK ही install करें।

यह workflow सिर्फ मौजूदा prototype की APK बनाता है; AI engine इसमें शामिल नहीं है। GitHub की UI या policy में बदलाव होने पर चरण थोड़े अलग हो सकते हैं।

## प्रोजेक्ट विवरण
- Minimum Android: 8.0 (API 26)
- Compile SDK: 35
- नेटवर्क permission नहीं माँगी जाती।
